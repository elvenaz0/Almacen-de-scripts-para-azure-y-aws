
# 📦 Descripción de Scripts - scriptschatgg-xxx

Este paquete contiene todos los scripts generados en la sesión de configuración, automatización y validación de servicios en AWS. A continuación se describe la función de cada uno:

---

## 🔐 Seguridad y usuarios

- **reset_passwords_fidexprod3.sh**  
  Script inicial para cambiar contraseñas de usuarios Windows usando AWS SSM.

- **reset_passwords_fidexprod3_force_change.sh**  
  Versión mejorada que también fuerza el cambio de contraseña en el próximo inicio de sesión.

- **reset_passwords_fidexprod3_direct.sh**  
  Corrige el envío usando `--instance-ids` en lugar de `--targets`.

- **reset_y_verificar_fidexprod3.sh**  
  Script completo que cambia contraseñas y verifica automáticamente el resultado.

---

## ✅ Verificación de ejecución

- **verificar_resultado_ssm.sh**  
  Permite verificar el resultado de un `CommandId` específico ejecutado vía SSM.

- **verificar_ultimo_resultado_ssm.sh**  
  Detecta el último comando ejecutado y obtiene automáticamente su resultado.

---

## ⚙️ Configuración de red y balanceadores

- **describe_alb_ascys.sh**  
  Describe el ALB `ALB-ASCys-FTP`, incluyendo listeners, reglas y target groups.

- **configurar_puertos_sg.sh**  
  Aplica reglas de apertura de puertos 10300, 10301, y 10204 en dos Security Groups.

- **verificar_alb_y_sg_completo.sh**  
  Verifica configuración de ALB y reglas de SG y guarda todo en un JSON.

---

## 🔄 AWS Transfer Family (SFTP)

- **verificar_estado_sftp_transfer_json.sh**  
  Verifica estado del servidor Transfer Family y guarda info en un JSON.

- **eliminar_sftp_y_dns.sh**  
  Elimina usuarios, servidor SFTP y registros DNS relacionados.

---

## 🧪 Diagnóstico de conectividad SSM

- **verificar_ssm_estado_fidexprod3.sh**  
  Verifica si una instancia está correctamente registrada en AWS Systems Manager.

---

_Archivo generado automáticamente._
